#include "../include/cameraMeasurement.h"
#include <vector>
#include <cmath>
#include "../include/constValues.h"
using namespace std;
using namespace cv;

const vector<Point3f> POINT_3D_OF_ARMOR_BIG = vector<Point3f>
        {
            Point3f(-105, -30, 0), //top left
            Point3f(105, -30, 0),  //top right
            Point3f(105, 30, 0),   // bottom right
            Point3f(-105, 30, 0)  // bottom left
        };

const vector<Point3f>  POINT_3D_OF_ARMOR_SMALL = vector<Point3f>
        {
                Point3f(-65, -35, 0),	//tl
                Point3f(65, -35, 0),	//tr
                Point3f(65, 35, 0),		//br
                Point3f(-65, 35, 0)		//bl
        };


pair<double, double> calAngle(const CameraParams& params,int x,int y)
{
    auto cam = params.cameraMatrix;
    auto dis = params.distCoeffs;
    double fx=cam.at<double>(0,0);
    double fy=cam.at<double>(1,1);
    double cx=cam.at<double>(0,2);
    double cy=cam.at<double>(1,2);
    double k1=dis.at<double>(0);
    double k2=dis.at<double>(1);
    double p1=dis.at<double>(2);
    double p2=dis.at<double>(3);

    Point2f pnt;
    vector<cv::Point2f>in;
    vector<cv::Point2f>out;
    in.push_back(Point2f(x,y));

    //调用opencv内置函数对像素点去畸变
    undistortPoints(in,out,cam,dis,noArray(),cam);

    pnt=out.front();
    double tanx=(pnt.x-cx)/fx;
    double tany=(pnt.y-cy)/fy;

    auto angleX = atan(tanx)/CV_PI*180.0;
    auto angleY = atan(tany)/CV_PI*180.0;

    return {angleX, angleY};
}

double calDistance(const CameraParams& params, const int armorBoxType, const vector<Point2f> detectedArmorPoints)
{
    Mat rotationVec = Mat::zeros(3, 1, CV_64FC1);
    Mat translationVec = Mat::zeros(3, 1, CV_64FC1);
    if(armorBoxType == ARMORBOX_BIG)
    {
        solvePnP(POINT_3D_OF_ARMOR_BIG, detectedArmorPoints, params.cameraMatrix, params.distCoeffs, rotationVec, translationVec, false, SOLVEPNP_ITERATIVE);
    }
    else if(armorBoxType == ARMORBOX_SMALL)
    {
        solvePnP(POINT_3D_OF_ARMOR_SMALL, detectedArmorPoints, params.cameraMatrix, params.distCoeffs, rotationVec, translationVec, false, SOLVEPNP_ITERATIVE);
    }
    translationVec.at<double>(1, 0) -= DIST_BETWEEN_GUN_AND_CAMERA; // TODO
    double dist = sqrt(translationVec.dot(translationVec));

    return dist;
}

bool getCameraParams(const string& paramFilePath, CameraParams& params)
{
    FileStorage fs(paramFilePath, FileStorage::READ);
    if(fs.isOpened()) {
        fs["camera_matrix"] >> params.cameraMatrix;
        fs["distortion_coefficients"] >> params.distCoeffs;
        return true;
    }
    else
    {
        printf("[Error] camera params file open failed.\n");
        return false;
    }
}


