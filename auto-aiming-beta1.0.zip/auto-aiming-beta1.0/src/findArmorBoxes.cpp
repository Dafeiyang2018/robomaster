#include "../include/findArmorBoxes.h"
#include "multithread_classifier.h"
// 长宽比 
static inline double get_lw_rate(const cv::RotatedRect& rect) 
{
    return rect.size.height > rect.size.width ?
        rect.size.height / rect.size.width :
        rect.size.width / rect.size.height;
}

// 倾斜角大小（-180 ~ 0）
static inline double get_angle(const cv::RotatedRect& rect)
{
    return rect.size.height > rect.size.width ? rect.angle - 90.0 : rect.angle;
}

// 有效面积与外接长方形面积之比
static inline double areaRatio(const std::vector<cv::Point>& contour, const cv::RotatedRect& rect) {
    return cv::contourArea(contour) / rect.size.area();
}

static inline double get_angle_diff(const RotatedRect& rect_i, const RotatedRect& rect_j)
{
    return abs(get_angle(rect_i) - get_angle(rect_j));
}

static inline double get_height_diff(const RotatedRect& rect_i, const RotatedRect& rect_j) 
{
    return abs(rect_i.center.y - rect_j.center.y);
}

static inline double get_lwrate(const RotatedRect& rect_i, const RotatedRect& rect_j) 
{
    double side_length, rect_length;
    cv::Point2f centers = rect_i.center - rect_j.center;
    side_length = sqrt(centers.ddot(centers));
    rect_length = MAX(MAX(rect_i.size.width, rect_i.size.height), MAX(rect_j.size.width, rect_j.size.height));

    return  side_length / rect_length;
}

static inline double get_lengthRatio(const RotatedRect& rect_i, const RotatedRect& rect_j) {
    double rect_length_i, rect_length_j;
    rect_length_i = MAX(rect_i.size.width, rect_i.size.height);
    rect_length_j = MAX(rect_j.size.width, rect_j.size.height);
    return MAX(rect_length_i / rect_length_j, rect_length_j / rect_length_i);
}

// 是否是灯条
static bool isValidLightBlob(const cv::RotatedRect& rect)
{
    // 以下是各种参数的阈值
    static const double low_lw_rate = 1;
    static const double large_lw_rate = 15.0;
    static const double low_angle = -120.0;
    static const double large_angle = -60.0;
    static const double low_area = 20;
    static const double large_area = 2000;

    bool check1 = low_lw_rate < get_lw_rate(rect) && get_lw_rate(rect) < large_lw_rate;
    bool check2 = get_angle(rect) > low_angle && get_angle(rect) < large_angle;
    bool check3 = rect.size.area() > low_area && rect.size.area() < large_area;

    //printf("angle: %f\tlw_rate: %f\tsize: (%f, %f)\tarea: %f\n", get_angle(rect), lw_rate(rect), rect.size.width, rect.size.height, rect.size.area());
    return check1 && check2 && check3;
}


// 两个灯条是否匹配
static bool isCoupleLight(const RotatedRect& rect_i, const RotatedRect& rect_j, uint8_t enemy_color)
{
    double angel_diff = get_angle_diff(rect_i, rect_j);
    double height_diff = get_height_diff(rect_i, rect_j);
    double length_radio = get_lengthRatio(rect_i, rect_j);
    double lwrate = get_lwrate(rect_i, rect_j);

    static const double k0 = 2;
    static const double k1 = 3;
    static const double k2 = 0.7;
    bool check1 = angel_diff < 20;
    bool check2 = height_diff < 30;
    bool check3 = length_radio < k0;
    bool check4 = lwrate < k1&& lwrate > k2;

    //printf("a_diff: %f\t h_diff: %f \t l_radio: %f \t lwrate: %f\n", angel_diff, height_diff, length_radio, lwrate);   

    return check1 && check2 && check3 && check4;
}

void find_blobs(const Mat& src, vector<RotatedRect>& rst)
{
    Mat src_hsv, src_small, img_bin;

    static const double resize_k =  0.25;
    static const cv::Mat kernel_dilate = getStructuringElement(cv::MORPH_RECT, cv::Size(3, 3));
    resize(src, src_small, Size(0, 0), resize_k, resize_k);
    cvtColor(src_small, src_hsv, COLOR_BGR2HSV);

    img_bin.create(src_hsv.size(), CV_8UC1);
    Vec3b pixel;
    uchar h, s, v;
    for (int row = 0, rows = src_hsv.rows; row < rows;++row)
    {
        for (int col = 0, cols = src_hsv.cols; col < cols; ++col)
        {
            pixel = src_hsv.at<Vec3b>(row, col);
            h = pixel[0], s = pixel[1], v = pixel[2];
            if (h > 80 && h < 110 &&s > 50 && s < 200 && v > 200)
            {
                img_bin.at<uchar>(row, col) = 255;
            }
            else if (s < 25 && v > 240)
            {
                img_bin.at<uchar>(row, col) = 255;
            }
            else
            {
                img_bin.at<uchar>(row, col) = 0;
            }
        }
    }

    dilate(img_bin, img_bin, kernel_dilate);

    /*static cv::Mat kernel_erode = getStructuringElement(cv::MORPH_RECT, cv::Size(3, 3));
    erode(dst, dst, kernel_erode);*/

    
    vector<std::vector<cv::Point>> roi_contours;
    std::vector<cv::Vec4i> roi_hierarchy;
    cv::findContours(img_bin, roi_contours, roi_hierarchy, RETR_EXTERNAL, CHAIN_APPROX_NONE);
    
    for (int i = 0; i < roi_contours.size(); i++)
    {
        if (roi_hierarchy[i][2] == -1)
        {
            //cv::RotatedRect rect = cv::minAreaRect(light_contours[i]);

            static const double enlarge_k = 2; // �Ŵ���
            auto rect_resized = boundingRect(roi_contours[i]);
            auto rect_src = Rect(rect_resized.tl() / resize_k, rect_resized.br() / resize_k);
            auto center_src = (rect_src.tl() + rect_src.br()) / 2;
            
            auto tl = Point2i(MAX(center_src.x - rect_src.width * enlarge_k / 2, 0),
                              MAX(center_src.y - rect_src.height * enlarge_k / 2, 0));
            auto br = Point2i(MIN(center_src.x + rect_src.width * enlarge_k / 2, src.cols),
                              MIN(center_src.y + rect_src.height * enlarge_k / 2, src.rows));
            auto rect_roi = Rect(tl, br);

            Mat roi_bgr = src(rect_roi), roi_gray, roi_th;
            cvtColor(roi_bgr, roi_gray, COLOR_BGR2GRAY);
            threshold(roi_gray, roi_th, 0, 255, THRESH_OTSU);;
            vector<std::vector<cv::Point>> light_contours;
            std::vector<cv::Vec4i> light_hierarchy;
            cv::findContours(roi_th, light_contours, light_hierarchy, RETR_EXTERNAL, CHAIN_APPROX_NONE);
            //imshow("roi_gray", roi_gray);
            double max_area = -1;
            RotatedRect max_light_rect;
            for (int j = 0; j < light_contours.size(); j++)
            {
                if (light_hierarchy[j][2] == -1)
                {
                    auto rect_light = cv::minAreaRect(light_contours[j]);
                    if (rect_light.size.area() > max_area)
                    {
                        max_light_rect = rect_light;
                        max_area = rect_light.size.area();
                    }
                }
            }

            if (isValidLightBlob(max_light_rect))
            {
                max_light_rect.center += (Point2f)rect_roi.tl();
                rst.emplace_back(max_light_rect);
            }
        }
    }

    // debug 
    //Mat show = src.clone();
    //Mat show2 = show.clone();
    //Mat gray;
    //cvtColor(src, gray, COLOR_BGR2GRAY);
    //Mat bin2;
    //resize(img_bin, bin2, Size(0, 0), 1.0 / resize_k, 1.0 / resize_k);
    //for (int row = 0, rows = show.rows; row < rows; ++row)
    //{
    //    for (int col = 0, cols = show.cols; col < cols; ++col)
    //    {
    //        if (!bin2.at<uchar>(row, col))
    //        {
    //            uchar p = gray.at<uchar>(row, col);
    //            show2.at<Vec3b>(row,col) = Vec3b(p/10, p/10, p/10);
    //        }
    //    }
    //}

    //for (auto &r : rst)
    //{
    //    ellipse(show, r, Scalar(0,255,0), CV_FILLED);
    //}
    //static int img_idx = 0;
    //cv::putText(img_bin, to_string(img_idx++), Point(40, 40), FONT_HERSHEY_COMPLEX, 1, Scalar(255));
    //resize(show, show, Size(0, 0), 0.5, 0.5);
    //resize(show2, show2, Size(0, 0), 0.5, 0.5);
    //cv::imshow("bin", img_bin);
    //cv::imshow("show1", show);
    //cv::imshow("show2", show2);

    ////static int save_idx = 0;
    ////imwrite("D://RM-DATASET//video//battle1//" + to_string(save_idx++) + ".jpg", src);
    //cv::waitKey(1);
}

bool matchArmorBoxes(const cv::Mat& src, const vector<RotatedRect>& light_blobs, vector<ArmorBox>& armor_boxes)
{
    armor_boxes.clear();

    for (int i = 0; i < light_blobs.size(); ++i)
    {
        for (int j = i + 1; j < light_blobs.size(); ++j)
        {
            if (!isCoupleLight(light_blobs[i], light_blobs[j], 0))
            {
                continue;
            }

            Point2f points_i[4], points_j[4]; 
            light_blobs.at(i).points(points_i); // ��ȡ����
            light_blobs.at(j).points(points_j);
            vector<Point2f> points = { points_i[0], points_i[1], points_i[2], points_i[3],
                                       points_j[0], points_j[1], points_j[2], points_j[3] };
            auto r = cv::minAreaRect(cv::Mat(points));

            static const double kx = 0.7, ky = 1.8;// x,y �����ı���

            if (r.angle > -45)
            {
                r.size = Size2f(r.size.width * kx, r.size.height * ky);
            }
            else
            {
                r.size = Size2f(r.size.width * ky, r.size.height * kx);
            }

            armor_boxes.emplace_back(ArmorBox(-1, -1, r, light_blobs[i], light_blobs[j]));

        }
    }
    return !armor_boxes.empty();
}

ArmorBoxesDetector::ArmorBoxesDetector(int max_thread_num, const string& modelfile):classifier(modelfile, max_thread_num)
{
}

void ArmorBoxesDetector::operator()(const Mat& src, vector<ArmorBox>& rst, vector<RotatedRect>& blobs, vector<ArmorBox>& suspects)
{
    vector<RotatedRect> blobs;
    vector<ArmorBox> armorboxes;
    vector<Mat> rois;
    vector<ArmorBox> rst;

    find_blobs(src, blobs);

    //return rst;

    matchArmorBoxes(src, blobs, armorboxes);

    for (auto &box : armorboxes)
    {
        Point2f src_vertexes[4];
        Point2f dst_vertexes[4];
        Mat roi;
        RotatedRect& r = box.pos;
        r.points(src_vertexes);
        if (r.angle < -45)
        {
            dst_vertexes[0] = { r.size.width, r.size.height };
            dst_vertexes[1] = { 0, r.size.height };
            dst_vertexes[2] = { 0, 0 };
            dst_vertexes[3] = { r.size.width,0 };
        }
        else
        {
            dst_vertexes[0] = { 0, r.size.height };
            dst_vertexes[1] = { 0, 0 };
            dst_vertexes[2] = { r.size.width,0 };
            dst_vertexes[3] = { r.size.width, r.size.height };
        }

        Mat warpMatrix = getPerspectiveTransform(src_vertexes, dst_vertexes);
       
        cv::warpPerspective(src, roi, warpMatrix, r.size);
        rois.emplace_back(roi);
    }


    auto classify_rst = classifier(rois);

    for (int i = 0, end = armorboxes.size(); i < end; i++)
    {
        armorboxes[i].number = classify_rst[i];
        rst.emplace_back(armorboxes[i]);
    }

    return rst;
}

void ArmorBoxesDetector::draw(const Mat& src, Mat &dst, const vector<ArmorBox> &rst, const vector<RotatedRect> &blobs, const vector<ArmorBox> &suspects)
{
    dst = src.clone();
    static auto yellow = Scalar(255,255,128);
    static auto purple = Scalar(128,0,255);
    static auto green = Scalar(0,255,0);
    static auto blue = Scalar(255, 0, 0);
    static auto red = Scalar(0, 0, 255);

    // 画可能的灯条
    for(auto & b : blobs)
    {
        ellispe(dst, b, yellow, CV_FILLED);
    }

    // 画初步识别的装甲板
    for(auto & box : suspects)
    {
        auto rrect = box.pos;
        cv::Point2f vertex[4];
        rrect.points(vertex);
        for (int i = 0; i < 4; i++)
        {
            cv::line(dst, vertex[i], vertex[(i + 1) % 4], blue, 2, LINE_AA);
        }
    }
    // 画真实装甲板
    for (auto & box : rst)
    {
        auto rrect = box.pos;
        auto n = box.number;
        if (n == 0)
            continue;
        cv::Point2f vertex[4];
        rrect.points(vertex);
        for (int i = 0; i < 4; i++)
        {
            cv::line(dst, vertex[i], vertex[(i + 1) % 4], purple, 2, LINE_AA);
        }
        ellipse(dst, box.light_blob1, green, CV_FILLED);
        ellipse(dst, box.light_blob2, green, CV_FILLED);
        putText(dst, to_string(n), rrect.center, FONT_HERSHEY_COMPLEX, 1, green);
    }          
    putText(dst, to_string(imgIdx), Point(40, 40), FONT_HERSHEY_COMPLEX, 1, red);
}

ArmorBox::ArmorBox(int color, int number, const RotatedRect& pos, const RotatedRect& lb1, const RotatedRect& lb2):
    color(color), number(number), pos(pos), light_blob1(lb1), light_blob2(lb2)
{
}
