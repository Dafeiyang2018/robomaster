#include "../include/torch.h"
#include "opencv.hpp"   
using namespace cv;

MatrixXd Conv2d::conv(const MatrixXd& filter, const MatrixXd& input) const
{
    int result_rows = input.rows() - filter.rows() + 1;
    int result_cols = input.cols() - filter.cols() + 1;
    MatrixXd result(result_rows, result_cols);
    for (int row = 0; row < result_rows; row++) 
    {
        for (int col = 0; col < result_cols; col++) 
        {
            double val = 0;
            for (int x = 0, xend = filter.cols(); x < xend; x++) 
            {
                for (int y = 0, yend = filter.rows(); y < yend; y++) 
                {
                    val += input(row + x, col + y) * filter(x, y);
                }
            }
            result(row, col) = val;
        }
    }
    return result;
}

Conv2d::Conv2d(const Tensor4d& w, const Tensor4d& b): conv_w(w),conv_b(b){}

Tensor4d Conv2d::operator()(const Tensor4d& input) const 
{
    //尺寸检查 略

    Tensor4d result;
    int result_rows = input[0][0].rows() - conv_w[0][0].rows() + 1;
    int result_cols = input[0][0].cols() - conv_w[0][0].cols() + 1;
    int samples = (int)input.size();
    int out_channels = (int)conv_w.size();
    int in_channels = (int)conv_w[0].size();

    for (int sample_idx = 0; sample_idx < samples; sample_idx++) 
    {
        vector<MatrixXd> sub;
        for (int out_channel_idx = 0; out_channel_idx < out_channels; out_channel_idx++)
        {
            MatrixXd val = MatrixXd::Zero(result_rows, result_cols);
            for (int in_channel_idx = 0; in_channel_idx < in_channels; in_channel_idx++) 
            {
                val += conv(conv_w[out_channel_idx][in_channel_idx], input[sample_idx][in_channel_idx]); // 卷积
            }
            val = val.array() + conv_b[0][0](out_channel_idx,0);// 加bias
            sub.emplace_back(val);
        }
        result.emplace_back(sub);
    }
    return result;
}

MatrixXd Relu::relu(const MatrixXd& input) const
{
    return input.unaryExpr([](double val) {
        return (val > 0) ? (val) : (0);
    });
}

Relu::Relu(){}

Tensor4d Relu::operator()(const Tensor4d& input) const 
{
    int samples = (int)input.size();
    int channels = (int)input[0].size();

    Tensor4d result;

    for (int sample_idx = 0; sample_idx < samples; sample_idx++) {
        vector<MatrixXd> sub;
        for (int channel_idx = 0; channel_idx < channels; channel_idx++) {
            sub.emplace_back(relu(input[sample_idx][channel_idx]));
        }
        result.emplace_back(sub);
    }
    return result;
}

Max_pool2d::Max_pool2d(const int kernel_size):kernel_size(kernel_size) {}

Tensor4d Max_pool2d::operator()(const Tensor4d& input)const
{
    int samples = (int)input.size();
    int channels = (int)input[0].size();

    Tensor4d result;

    for (int sample_idx = 0; sample_idx < samples; sample_idx++) 
    {
        vector<MatrixXd> sub;
        for (int channel_idx = 0; channel_idx < channels; channel_idx++) 
        {
            MatrixXd tmp(input[0][0].rows() / kernel_size, input[0][0].cols() / kernel_size);
            for (int row = 0, rows = tmp.rows(); row < rows; row++) 
            {
                for (int col = 0, cols = tmp.cols(); col < cols; col++) 
                {
                    double max = 0;
                    for (int x = 0; x < kernel_size; x++) 
                    {
                        for (int y = 0; y < kernel_size; y++) 
                        {
                            if (max < input[sample_idx][channel_idx](row* kernel_size + x, col* kernel_size + y)) 
                            {
                                max = input[sample_idx][channel_idx](row* kernel_size + x, col* kernel_size + y);
                            }
                        }
                    }
                    tmp(row, col) = max;
                }
            }
            sub.emplace_back(tmp);
        }
        result.emplace_back(sub);
    }
    return result;
}

Tensor4d Flatten::operator()(const Tensor4d& input) const 
{
    int samples = (int)input.size();
    int channels = (int)input[0].size();
    int rows = (int)input[0][0].rows();
    int cols = (int)input[0][0].cols();

    Tensor4d result = { vector<MatrixXd>{MatrixXd(channels* rows*cols, samples)} };

    for (int sample_idx = 0; sample_idx < samples; sample_idx++) 
    {
        int flatten_idx = 0;
        for (int channel_idx = 0; channel_idx < channels; channel_idx++)
        {
            for (int row = 0; row < rows; row++)
            {
                for (int col = 0; col < cols; col++)
                {                    
                    result[0][0](flatten_idx, sample_idx) = input[sample_idx][channel_idx](row, col);
                    flatten_idx++;
                }
            }
        }
    }
    return result;
}

Flatten::Flatten(){}

Linear::Linear(const Tensor4d & w, const Tensor4d & b) :fc_w(w), fc_b(b) {};

Tensor4d Linear::operator()(const Tensor4d& input)const 
{
    Tensor4d result = { vector<MatrixXd>{MatrixXd()} };

    result[0][0] = fc_w[0][0] * input[0][0];
    result[0][0].colwise() += fc_b[0][0].col(0);
	return result;
}

Tensor4d NNModule::calculate(const Tensor4d& input) const
{
    Tensor4d output = input;
    for (NNLayer *layer: layers)
    {
        output = (*layer)(output);
       /* cout << output[0][0] << endl;
        cout << "\n\n\n =  ===============================================" << endl;*/
    }    
    return output;
}

bool NNModule::load(const string& modelfile)
{
    FileStorage fs(modelfile, FileStorage::READ); //填入读操作
    if (!fs.isOpened())
    {
        cerr << modelfile + "is not opened!!!\n";
        throw runtime_error(modelfile + "is not opened!!!\n");
        return false;
    }
    FileNode model_node = fs["modelinfo"];
    int dataIdx = 0;

    auto read_Tensor4d = [&](FileNode& node) {
        Tensor4d t;
        FileNode shape_node = node["shape"];
        FileNode data_node = node["listdata"];
        auto si = shape_node.begin();
        int out_channels = *(si++);
        int in_channels = *(si++);
        int rows = *(si++);
        int cols = *(si++);

        auto di = data_node.begin();
        for (int out_channel_idx = 0; out_channel_idx < out_channels; ++out_channel_idx){
            vector<MatrixXd> sub;
            for (int in_channel_idx = 0; in_channel_idx < in_channels; ++in_channel_idx){
                MatrixXd tmp(rows, cols);
                for (int row = 0; row < rows; ++row){
                    for (int col = 0; col < cols; ++col){
                        tmp(row, col) = (double)(*di++);
                        if (di == node.end()){
                            //出错了，张量读取出错
                        }
                    }
                }
                sub.emplace_back(tmp);
            }
            t.emplace_back(sub);
        }
        return t;
    };

    for (auto i = model_node.begin(); i != model_node.end(); i++)
    {
        string type = (*i)["type"];
        if (type == "conv2d")
        {           
            string weightparam ="data" + to_string(dataIdx++);
            string biasparam = "data" + to_string(dataIdx++);
            FileNode weight_node = fs[weightparam];
            FileNode bias_node = fs[biasparam];
            Tensor4d w = read_Tensor4d(weight_node);
            Tensor4d b = read_Tensor4d(bias_node);
            NNLayer* p = new Conv2d(w, b);
            layers.emplace_back(p);
        }
        else if (type == "linear")
        {
            string weightparam = "data" + to_string(dataIdx++);
            string biasparam = "data" + to_string(dataIdx++);
            FileNode weight_node = fs[weightparam];
            FileNode bias_node = fs[biasparam];
            Tensor4d w = read_Tensor4d(weight_node);
            Tensor4d b = read_Tensor4d(bias_node);
            NNLayer* p = new Linear(w, b);
            layers.emplace_back(p);
        }
        else if (type == "maxpool2d")
        {
            int kernel_size = (*i)["kernel_size"];
            NNLayer* p = new Max_pool2d(kernel_size);
            layers.emplace_back(p);
        }
        else if (type == "relu")
        {
            NNLayer* p = new Relu();
            layers.emplace_back(p);
        }
        else if (type == "flatten")
        {
            NNLayer* p = new Flatten();
            layers.emplace_back(p);
        }
        else
        {
            //type error
        }
    }

    return true;
}

NNModule::NNModule() {};

NNModule::NNModule(const string& modelfile)
{
    load(modelfile);
}

int NNModule::operator()(const cv::Mat& image) const
{
    vector<MatrixXd> sub;
    
    if (image.channels() == 3)
    {
        MatrixXd r, g, b;
        std::vector<cv::Mat> channels;
        cv::split(image, channels);
        cv2eigen(channels[0], b);
        cv2eigen(channels[1], g);
        cv2eigen(channels[2], r);
        r /= 255;
        g /= 255;
        b /= 255;
        sub = { b, g, r };
    }
    else if (image.channels() == 1)
    {
        MatrixXd gray;
        cv2eigen(image, gray);
        gray /= 255;
        sub = { gray };
    }
    else
    {
        printf("input image channels error!\n");
        return -1;
    }
    
    Tensor4d in = { sub };

    Tensor4d result = calculate(in);
    MatrixXd::Index maxRow, maxCol;
    result[0][0].maxCoeff(&maxRow, &maxCol);
    if (result[0][0](maxRow, maxCol) > 0) 
    {
        return maxRow;
    }
    else 
    {
        return 0;
    }
}

NNModule::~NNModule()
{
    for (NNLayer* layer : layers)
    {
       delete layer;
    }
}
