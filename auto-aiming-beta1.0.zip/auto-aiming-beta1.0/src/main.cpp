﻿#include "opencv2/opencv.hpp"
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "../include/torch.h"
#include "../include/findArmorBoxes.h"
#include "../include/cameraManagement.h"
#include "../include/cameraMeasurement.h"
#include "../include/manifoldCommunication.h"

using namespace cv;
using namespace std;

#define DEBUG

int main()
{
    int nBuffSize = 0;
    unsigned char* pFrameBuf = nullptr;
    MV_FRAME_OUT_INFO_EX stInfo;

    // 打开相机
    auto cameraHandle = openCamera(pFrameBuf, nBuffSize, stInfo);
    if(nullptr == cameraHandle)
        return 1;

    // 相机打开成功，读取测量好的相机内参
    auto cameraParams = CameraParams();
    // bug here
    if(!getCameraParams("data/out_camera_data.xml", cameraParams)) {
        printf("[Error] Camera params load fails.\n");
        return 1;
    };

    // 初始化串口
    const char* manifoldSerialPath = "/dev/ttyTHS2";
    const int baudrate = 115200;
    auto fd = initializeSerial(manifoldSerialPath, baudrate);
    if(fd < 0)
    {
#ifndef DEBUG
        return 1;
#else
        printf("[DEBUG] Communication message will be printed to stdout.\n");
#endif
    }
    // 初始化装甲板检测参数  
    string modelfile = "data/model.json"
    ArmorBoxesDetector detector(4, modelfile);
    
    vector<ArmorBox> rst;
    vector<RotatedRect> blobs;
    vector<ArmorBox> suspects;
    Mat srcImg, showImg;

    // 开始读取相机内容
    int imgNum = 0;
    while(waitKey(30) != 'q')
    {
        
        if(nullptr == readFromCamera(cameraHandle, srcImg, pFrameBuf, nBuffSize, stInfo))
        {
            printf("[Error] Read no image from camera.\n");
            break;
        } else if(srcImg.empty())
        {
            printf("[Error] Image read from camera is empty!\n");
            break;
        }
        else // 读取成功，识别装甲板
        {
            imgNum ++;
#ifdef DEBUG
            double t1 = getTickCount();
            detector(srcImg, rst, blobs, suspects);
            double t2 = getTickCount();
            auto dt = (t2 - t1) / getTickFrequency() * 1000;
            LOG("dt" + to_string(dt) + "ms\n");
            output();
            detector.show(srcImg, showImg, rst, blobs, suspects);
            imshow("Camera Capture", showImg);
            cv::waitKey(10);
#else
            //find_armorboxes(newImg,detectRst);
            detector(srcImg, rst, blobs, suspects);

            // TODO: select armboxes.
            // send vision result from DJI manifold to STM32
#endif
        }
    }

    cameraExit(cameraHandle);    //退出相机
    close(fd);     //关闭串口
    //退出
    return 0;
}


