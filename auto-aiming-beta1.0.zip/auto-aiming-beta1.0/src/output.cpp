#include "../include/output.h"
#include <mutex>
#include <iostream>

string str;
mutex m_lock;

void LOG(const string& info)
{
	lock_guard<mutex> lock{ m_lock };
	str += info;
}

void output()
{
	lock_guard<mutex> lock{ m_lock };
	cout << str;
	str.clear();
}
