#include "../include/multithread_classifier.h"
#include "../include/output.h"

MultithreadClassifier::MultithreadClassifier(const string& modelfile, const int maxThreadNum): maxThreadNum(maxThreadNum), threadpool(maxThreadNum), model(modelfile)
{}

void normalize(const Mat& src, Mat& dst)
{
    int w0 = 48, h0 = 48;
    double w = src.cols, h = src.rows;
    double kw = w0 / w, kh = h0 / h;
    double k = MIN(kw, kh);
    int w1 = int(w * k), h1 = int(h * k);
    Mat dst_ = Mat::zeros(h0, w0, CV_8UC1);
    Mat tmp;
    resize(src, tmp, Size(w1, h1));
    int sx = int((w0 - w1) / 2), sy = int((h0 - h1) / 2);
    int ex = int(sx + w1), ey = int(sy + h1);

    tmp.copyTo(dst_.rowRange(sy, ey).colRange(sx, ex));
    dst = dst_;
    //resize(src, dst, Size(w0, h0));
}

void get_max_connectedComponent(const Mat& src, Mat& dst)
{
    Mat labels, centroids, stats;
    int nccomps = connectedComponentsWithStats(src, labels, stats, centroids);

    double max_area = -1;
    int max_label = -1;

    for (int i = 1; i < nccomps; ++i)
    {
        double area = stats.at<int>(i, CC_STAT_WIDTH) * stats.at<int>(i, CC_STAT_HEIGHT);
        if (area > max_area)
        {
            max_area = area;
            max_label = i;
        }
    }
    //cout << "max_area: " << max_area << endl;

    dst = Mat::zeros(src.size(), CV_8UC1);

    for (int y = 0; y < dst.rows; y++)
    {
        for (int x = 0; x < dst.cols; x++)
        {
            int label = labels.at<int>(y, x);
            if (label == max_label)
            {
                dst.at<uint8_t>(y, x) = 255;
            }
        }
    }
}


NNModule model;

string path_save = "D:/RM-DATASET/video/roi001/pics/";
string path_save2 = "D:/RM-DATASET/video/roi002/pics/";
int save_idx = 0;
mutex save_mutex;

vector<Mat> shows(100);

void preprocess(const Mat& src, Mat& dst, int i)
{
    Mat img_hsv, img_gray, img_gray2, mask, img_th, img_th2, img_norm;
    if (src.channels() != 3)
    {
        return;
    }
    cvtColor(src, img_hsv, COLOR_BGR2HSV);
    cvtColor(src, img_gray, COLOR_BGR2GRAY);
    img_gray2 = img_gray.clone();
    Vec3b pixel;
    uchar h, s, v;
    for (int i = 0; i < img_hsv.rows; i++)
    {
        for (int j = 0; j < img_hsv.cols; j++)
        {
            pixel = img_hsv.at<Vec3b>(i, j);
            h = pixel[0], s = pixel[1], v = pixel[2];
            if (v > 200 || (h > 70 && h < 140 && v > 100))
            {
                *img_gray2.ptr<uchar>(i, j) = 0;
            }
        }
    }
    //inRange(img_hsv, Scalar(70, 0, 100), Scalar(140, 255, 255), mask);
    int mean = cv::mean(img_gray2)[0] * 1.0;
    threshold(img_gray2, img_th, mean, 255, THRESH_BINARY);
    get_max_connectedComponent(img_th, img_th2);
    normalize(img_th2, img_norm);
    dst = img_norm;

    /* imwrite(path_save2 + to_string(n) + "_" + to_string(save_idx) + ".jpg", src);
     imwrite(path_save2 + to_string(n) + "_" + to_string(save_idx) + "_bin1.jpg", img_th);
     imwrite(path_save2 + to_string(n) + "_" + to_string(save_idx) + "_bin2.jpg", img_th2);*/


    //  Mat show = Mat(src.rows, src.cols * 5, CV_8UC3);

    //  cvtColor(img_gray, img_gray, COLOR_GRAY2BGR);
    //  cvtColor(img_gray2, img_gray2, COLOR_GRAY2BGR);
    //  cvtColor(img_th, img_th, COLOR_GRAY2BGR);
    //  cvtColor(img_th2, img_th2, COLOR_GRAY2BGR);

    //  int col_idx = 0;
    //  src.copyTo(show(Rect(src.cols * (col_idx++), 0, src.cols, src.rows)));
    //  img_gray.copyTo(show(Rect(src.cols * (col_idx++), 0, src.cols, src.rows)));
    //  img_gray2.copyTo(show(Rect(src.cols * (col_idx++), 0, src.cols, src.rows)));
    //  img_th.copyTo(show(Rect(src.cols * (col_idx++), 0, src.cols, src.rows)));
    //  img_th2.copyTo(show(Rect(src.cols * (col_idx++), 0, src.cols, src.rows)));

    //  resize(show, show, Size(0, 0), 5, 5);
    //  {
    //      unique_lock<mutex>lock(save_mutex);
    //      shows[i] = show;
    //      cout << "save" <<i<<endl;
    //  }
     
}

vector<int> MultithreadClassifier::operator()(const vector<Mat>& images)
{
    vector<future<int>>rst_future;
    vector<int> rst;
    int idx = 0;

    double t11 = getTickCount();
    for (const Mat& m : images)
    {
        rst_future.emplace_back(
            threadpool.commit([&] {
                double t1 = getTickCount();
                Mat img_norm;
                preprocess(m, img_norm, idx++);
                int n = model(img_norm);
                double t2 = getTickCount();
                auto dt = (t2 - t1) / getTickFrequency() * 1000;
                LOG("NNtime is " + to_string(dt) + "ms\n");
                //std::cout << "NN time: " << dt << " ms" << endl;
                return n;
                })
        );
    }
     
    int idx2 = 0;
    for (auto& r : rst_future)
    {
        cout << "get" <<idx2<< endl;
        int n = r.get();
        rst.emplace_back(n);

        //Mat show = shows[idx2++];
        ////imshow("show_num", show);
        //imwrite(path_save + to_string(save_idx++) + "_" + to_string(n) + ".jpg", show);
        ////waitKey(1);     
    }

    double t12 = getTickCount();
    auto dt = (t12 - t11) / getTickFrequency() * 1000;
    LOG("total NNtime is " + to_string(dt) + "ms\n");
    return rst;
}
