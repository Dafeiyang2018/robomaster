//
// Created by lizhehao on 2/19/21.
//

#include "Camera.h"

using namespace robowalker;

Camera::Camera() {
    this->nBuffSize = 0;
    this->pFrameBuf = nullptr;

}
