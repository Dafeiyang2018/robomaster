mkdir build
cd build
cmake ..
make -j5