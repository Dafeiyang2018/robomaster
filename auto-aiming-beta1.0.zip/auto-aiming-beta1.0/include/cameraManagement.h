#ifndef __CAMERAMANAGEMENT__
#define __CAMERAMANAGEMENT__

#include <memory.h>
#include "opencv2/opencv.hpp"
#include <cstdio>
#include <cstdlib>
#include "hikvision_camera_api/MvCameraControl.h"

#define MAX_IMAGE_DATA_SIZE   (1920*1200*3)
constexpr int default_exposure_time = 20000;

/*
 * @brief: 打开相机，如果打开成功则初始化参数pFrameBuf, nBuffSize, stInfo
 * @return: 如果打开成功，返回cameraHandle, 否则返回nullptr
 */
void* openCamera(unsigned char* &pFrameBuf, int& nBuffSize, MV_FRAME_OUT_INFO_EX& stInfo);

/*
 * @brief: 从相机中读取一张图片
 * @return: 如果读取成功，返回Mat, 否则返回nullptr
 */
cv::Mat* readFromCamera(void* cameraHandle, cv::Mat& output, unsigned char* pFrameBuf, const int nBuffSize, MV_FRAME_OUT_INFO_EX& stInfo);

void* cameraInit();
int cameraExit(void* cameraHandle);
bool PrintDeviceInfo(MV_CC_DEVICE_INFO* pstMVDevInfo);

#endif 