//
// Created by lizhehao on 2/19/21.
//

#ifndef ROBOWALKER_CAMERA_H
#define ROBOWALKER_CAMERA_H

#include <memory.h>
#include "opencv2/opencv.hpp"
#include <cstdio>
#include <cstdlib>
#include "hikvision_camera_api/MvCameraControl.h"

using namespace cv;

namespace robowalker {
    class Camera {
    public:
        Camera();
        ~Camera();

    private:
        int nBuffSize;
        unsigned char* pFrameBuf;
        MV_FRAME_OUT_INFO_EX stInfo;
        void* cameraHandle;

        typedef struct CameraParams
        {
            Mat cameraMatrix;
            Mat distCoeffs;
        }CameraParams;

    };
}


#endif //ROBOWALKER_CAMERA_H
