#ifndef __CONSTVALUES__
#define __CONSTVALUES__

#define FALSE 1
#define TRUE 0
#define FAIL -1
#define SUCCESS 0

constexpr double DIST_BETWEEN_GUN_AND_CAMERA = 0.0;

#endif