#ifndef OUTPUT_H
#define OUTPUT_H
#include <string>
using namespace std;
void LOG(const string& info);

void output();

#endif
