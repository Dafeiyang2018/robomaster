#ifndef __CAMERAMEASUREMENT__
#define __CAMERAMEASUREMENT__

#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>
using namespace cv;
using namespace std;

typedef struct CameraParams
{
    Mat cameraMatrix;
    Mat distCoeffs;
}
CameraParams;

const int ARMORBOX_BIG = 1;
const int ARMORBOX_SMALL = 0;

pair<double, double> calAngle(const CameraParams& params,int x,int y);

/*
 * @brief: Calculate the distance between gun and detected armor box
 */
double calDistance(const CameraParams& params, const int armorBoxType, const vector<Point2f> detectedArmorPoints);

bool getCameraParams(const string& paramFilePath, CameraParams& params);

#endif