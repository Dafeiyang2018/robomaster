#ifndef FINDARMORBOXES_H
#define FINDARMORBOXES_H

#include "opencv.hpp"
#include <iostream>
#include <vector>
#include "../include/multithread_classifier.h"

using namespace cv;
using namespace std;

struct ArmorBox
{
public:
	int color;
	int number;
	RotatedRect pos;
	RotatedRect light_blob1;
	RotatedRect light_blob2;
	ArmorBox(int color, int number, const RotatedRect& pos, const RotatedRect& lb1, const RotatedRect& lb2);
};

class ArmorBoxesDetector
{
private:
	MultithreadClassifier classifier;
public:
	ArmorBoxesDetector(int max_thread_num, const string& modelfile);
	
	void operator()(const Mat& src, vector<ArmorBox> &rst, vector<RotatedRect> &blobs, vector<ArmorBox> &suspects);
	
	void draw(const Mat& src, Mat &dst, const vector<ArmorBox> &rst, const vector<RotatedRect> &blobs, const vector<ArmorBox> &suspects);
	ArmorBoxesDetector(const ArmorBoxesDetector&) = delete;
};
#endif