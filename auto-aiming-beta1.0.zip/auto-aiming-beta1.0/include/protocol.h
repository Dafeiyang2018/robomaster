#include<cstdlib>
#include<cstdint>

typedef unsigned short int	uint16_t;

/*下位机发送给视觉（妙算）的数据结构体*/
typedef struct {
	
	int16_t pitch;//当前pitch角，单位-18000~18000对应-180°~180°，用云台电机反馈的角度-零点（待测）
	int16_t yaw;//当前yaw角，单位-18000~18000对应-180°~180°
	int16_t vx;//相对视角的左右方向速度，1m/s对应1000
	int16_t vy;//相对视角的前进方向速度，1m/s对应1000
    //第0位 表示敌方颜色，0表示敌方为红，1表示敌方为蓝
    //第1位 表示是否开启自瞄
    //第2位 表示是否击打能量机关
	bool color;
	bool is_auto_aiming_open;
	bool is_shooting_energy;
//	uint16_t msgflag;	//从低位开始

	
	/*可能需要的标志：自身是否处于小陀螺状态*/
}car_info;  // 下位机发送给妙算的数据必须以\n结尾

const int car_info_string_size = 28;

/*接收自视觉的数据结构体*/
typedef struct {
	/*目标偏差的角度*/
	int16_t delta_pitch;//单位-18000~18000对应-180°~180°
	int16_t delta_yaw;//单位-18000~18000对应-180°~180°
	/*目标的距离*/
	int16_t target_distance;//单位1000对应1米
	
	/*可能需要的变量*/
	// int16_t fire_delay;//下次发射的延迟 单位毫秒
	// uint16_t msgflag;//各种信息标志，如敌方是否处于小陀螺状态
	
}vision_info; 
