/*
- C++ 实现的简单的CNN
- 依赖Opencv3 和 Eigen3
- 需要利用pytorch 上导出模型数据（存在.json 文件里）
- 实现的功能有
    - Conv2d
	- Relu
	- Max_pool2d
	- FLatten
	- Linear

- 使用方法
    - 加载模型
	    NNModule model(modelfile);
	- 使用模型 
	    model(input_pic);
	  和pytorch 类似
*/

#pragma once

#ifndef TORCH_H
#define TORCH_H

#include <Eigen/Dense>
#include <opencv2/core/eigen.hpp>
#include <vector>
#include <string>
#include <opencv2/core.hpp>

using namespace std;
using namespace Eigen;

using Tensor4d = vector<vector<MatrixXd>>;

class NNLayer
{
public:
	virtual Tensor4d operator()(const Tensor4d& input) const = 0;
};

class Conv2d :public NNLayer
{
private:
	const Tensor4d conv_w;
	const Tensor4d conv_b;
	MatrixXd conv(const MatrixXd& filter, const MatrixXd& input) const;
public: 
	Conv2d(const Tensor4d& w, const Tensor4d& b);
	Tensor4d operator()(const Tensor4d& input) const;
};

class Relu :public NNLayer
{
private:
	MatrixXd relu(const MatrixXd& input) const;
public:
	Relu();
	Tensor4d operator()(const Tensor4d& input) const;
};

class Max_pool2d :public NNLayer
{
private:
	int kernel_size;
	//stride = kernel_size
public:
	Max_pool2d(const int kernel_size);
	Tensor4d operator()(const Tensor4d& input) const;
};

class Flatten :public NNLayer
{
public:
	Flatten();
	Tensor4d operator()(const Tensor4d& input) const;
};

class Linear :public NNLayer
{
private:
	const Tensor4d fc_w;
	const Tensor4d fc_b;
public:
	Linear(const Tensor4d& w, const Tensor4d& b);
	Tensor4d operator()(const Tensor4d& input) const;
};


// NN模型
class NNModule
{
public:
	vector<NNLayer*>layers;
	Tensor4d calculate(const Tensor4d& input) const;
public:
	bool load(const string& modelfile);
	NNModule();
	NNModule(const string& modelfile);
	int operator()(const cv::Mat& image) const;
	~NNModule();
};

#endif
