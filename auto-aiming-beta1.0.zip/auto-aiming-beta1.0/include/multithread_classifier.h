#ifndef MULTITHREAD_CLASSIFIER_H
#define MULTITHREAD_CLASSIFIER_H

#include "../include/torch.h"
#include "../include/threadpool.hpp"
#include "opencv.hpp"
#include <vector>

using namespace std;
using namespace cv;

class MultithreadClassifier
{
private:
	NNModule model;
	Threadpool threadpool;
	const int maxThreadNum;
public:
	MultithreadClassifier(const string& modelfile, const int maxThreadNum);
	vector<int> operator()(const vector<Mat>& images);
};

#endif