#ifndef __MANIFOLDCOMMUNICATION__
#define __MANIFOLDCOMMUNICATION__

#include <cstdio>     /*标准输入输出定义*/
#include <cstdlib>    /*标准函数库定义*/
#include <memory.h>
#include <unistd.h>    /*Unix标准函数定义*/
#include <sys/types.h> /**/
#include <sys/stat.h>  /**/
#include <fcntl.h>     /*文件控制定义*/
#include <termios.h>   /*PPSIX终端控制定义*/
#include <errno.h>     /*错误号定义*/
#include <string>
#include "protocol.h"
#include "constValues.h"

using namespace std;

constexpr int maxBufferSize = 512; 

int manifoldSendOnce(const int fd, const vision_info send_data);

int initializeSerial(const string& serialPortPath, const int baudrate = 115200);

vision_info assembleVisionInfoStruct(double angleX, double angleY, double dist);

#endif //__MANIFOLDCOMMUNICATION__