# 自瞄模块
### 组成部分
1. 海康威视工业相机调用
2. 装甲板识别模块
3. 工业相机单目测角度、测距模块
4. 妙算与下位机的通信模块

执行逻辑请见`src/main.cpp`

### 依赖
+ cmake >= 2.8.0
+ g++
+ opencv
+ eigen3


### 如何运行
在妙算上执行下述命令.
```shell
sudo chmod u+x build.sh
./build.sh
./robowalker_autoAiming